# Default error pages
Configure your web server with path to `<renderedPagesDirectory>/<errorCode>/index.html`  
You do not need to edit this files.
